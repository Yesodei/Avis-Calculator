//
//  ViewController.swift
//  Avis_Calculator
// CREATED BY : ABRAHAM ROSENGARD
//  Created by arosenga on 9/13/17.
//  Copyright © 2017 arosenga. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    var screenNumber1:Double = 0;
    var screenNumber2:Double = 0;
    var previousNumber:Double = 0;
    let pastNumbers = "";
    let negative:Double = -1;
    var upperLine = 0;
    var performingMath = false;
    var operation = 0;
    

    
    @IBOutlet weak var screenOne: UILabel! //For current numbers

    @IBOutlet weak var screenUp: UILabel! // Shows previous operation
    
    
    //Digits function: 0-9
    
    @IBAction func Digits(_ sender: UIButton) {
        
        if performingMath == true
        {
             screenOne.text = String(sender.tag)
             screenNumber1 = Double(screenOne.text!)!;
             performingMath = false;
           }
     else{
         screenOne.text = screenOne.text! + String(sender.tag)
            screenNumber1 = Double(screenOne.text!)!
            
        }
  

        
        
    }
    
    
    // Operators +, -, x, /, (, ), CE, +/-, and  =

    @IBAction func Operators(_ sender: UIButton) {
      // makes screeOne not empty, CE, (, or = before doing operation
      if screenOne.text != "" && sender.tag != 17 && sender.tag != 18 && sender.tag != 15
      {
        previousNumber = Double(screenOne.text!)!
        
        if sender.tag == 11 //Add
        {
            screenOne.text = "+"
        }
        if sender.tag == 12 //Subtract
        {
            screenOne.text = "-"
        }
        if sender.tag == 13 //Multiply
        {
            screenOne.text = "x"
        }
        if sender.tag == 14 //Divide
        {
            screenOne.text = "/"
        }
       
        operation = sender.tag;
        performingMath = true;
        }
        else if sender.tag == 15 //press '=' button
      {
        
      
        
        
        //let pastNumbers = String(previousNumber) operation String(screenNumber1);
       // screenUp.text = pastNumbers;
        
        if operation == 11
        {
            screenOne.text = String(previousNumber + screenNumber1);
            
            
        }
        else if  operation == 12
        {
            screenOne.text = String(previousNumber - screenNumber1);
        }
        else if operation == 13
        {
            screenOne.text = String(previousNumber * screenNumber1);
        }
        else if operation == 14
        {
            screenOne.text = String(previousNumber / screenNumber1);
        }
        
        
        }
       
        if sender.tag == 17 //press CE
      {
        screenOne.text = "";
        screenUp.text = "";
        previousNumber = 0;
                             // let pastNumbers = "";
        screenNumber1 = 0;
        screenNumber2 = 0;
        }
        
        if sender.tag == 10   // press+/-
      {
                    screenOne.text = String(negative * Double(screenOne.text!)!);
                     //screenOne.text = String(negative);
        
        }
       
    
    
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    

}

